using Mirror;
using UnityEngine;

public class NetworkCharacter : NetworkBehaviour
{
    [SerializeField] private CharacterEquipmentHandler equipmentHandler;
    [SerializeField] private CharacterStateManager stateManager;
    [SerializeField] private FirebaseCharacterSync firebaseSync;
    [SerializeField] private InitializeUI initializeUI;
    [SerializeField] private SceneLoader sceneLoader;
    public CharacterState CurrentState => stateManager.currentState;
    public PlayerFacing CurrentDirection => stateManager.currentDirection;
    public override void OnStartClient()
    {
        base.OnStartClient();
        equipmentHandler.ApplyCharacterEquipment();
    }

    public override void OnStartServer()
    {
        base.OnStartServer();
        firebaseSync.InitializeFirebase();
    }

    public override void OnStartLocalPlayer()
    {
        base.OnStartLocalPlayer();
        firebaseSync.SetupUserData();
    }

    [Command]
    public void CmdChangeEquipment(int newHead, int newBody, int newHair, int newTorso, int newLegs)
    {
        equipmentHandler.CmdChangeEquipment(newHead, newBody, newHair, newTorso, newLegs);
    }

    [Command]
    public void CmdSaveLocation(string sceneName)
    {
        firebaseSync.CmdSaveLocation(sceneName, transform.position);
    }

    [Command]
    public void CmdUpdateState(CharacterState newState, PlayerFacing newDirection)
    {
        stateManager.CmdUpdateState(newState, newDirection);
    }
}
